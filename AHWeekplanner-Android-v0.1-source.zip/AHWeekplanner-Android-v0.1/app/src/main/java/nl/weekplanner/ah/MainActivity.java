package nl.weekplanner.ah;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.*;
import android.webkit.*;
import android.widget.*;

import java.time.*;
import java.time.temporal.WeekFields;
import java.util.*;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private LinearLayout content;
    private final PlannerEngine planner = new PlannerEngine();
    private AhClient ah;
    private List<PlannerEngine.Meal> currentWeek = new ArrayList<>();
    private final Map<String, Integer> matchedProducts = new LinkedHashMap<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        ah = new AhClient(this);
        handleCallback(getIntent());
        showHome();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleCallback(intent);
    }

    private void base(String title) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245,245,245));

        TextView header = tv(title, 24, true);
        header.setTextColor(Color.WHITE);
        header.setBackgroundColor(Color.rgb(20,20,20));
        header.setPadding(28,32,20,32);
        root.addView(header, new LinearLayout.LayoutParams(-1,-2));

        HorizontalScrollView navScroll = new HorizontalScrollView(this);
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.addView(navButton("Week", v -> showHome()));
        nav.addView(navButton("Boodschappen", v -> showGroceries()));
        nav.addView(navButton("AH koppelen", v -> showAh()));
        nav.addView(navButton("Instellingen", v -> showSettings()));
        navScroll.addView(nav);
        root.addView(navScroll);

        ScrollView sv = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(28,24,28,40);
        sv.addView(content);
        root.addView(sv, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    private void showHome() {
        base("Weekplanner");
        LocalDate today = LocalDate.now();
        LocalDate monday = today.minusDays(today.getDayOfWeek().getValue()-1);
        currentWeek = planner.makeWeek(monday);
        int week = monday.get(WeekFields.ISO.weekOfWeekBasedYear());
        content.addView(tv("Week " + week + " • " + monday + " t/m " + monday.plusDays(6),18,true));
        content.addView(tv("Profiel: gezond & lekker • overgang • psoriasisvriendelijke basis • eenvoudig koken",14,false));

        for (PlannerEngine.Meal m : currentWeek) {
            LinearLayout card = card();
            card.addView(tv(m.day + "  •  " + m.persons + " personen",16,true));
            card.addView(tv(m.title,17,true));
            card.addView(tv(m.category,13,false));
            content.addView(card);
        }
        Button gen = action("Genereer nieuw weekmenu");
        gen.setOnClickListener(v -> { currentWeek = planner.makeWeek(monday); showHome(); });
        content.addView(gen);

        Button list = action("Maak boodschappenlijst");
        list.setOnClickListener(v -> showGroceries());
        content.addView(list);
    }

    private void showGroceries() {
        base("Boodschappen");
        if (currentWeek.isEmpty()) {
            LocalDate t = LocalDate.now();
            currentWeek = planner.makeWeek(t.minusDays(t.getDayOfWeek().getValue()-1));
        }
        LinkedHashSet<String> set = new LinkedHashSet<>();
        set.add("Kinder Bueno");
        set.add("halfvolle yoghurt");
        set.add("fruit");
        set.add("ongezouten noten");
        for (PlannerEngine.Meal m : currentWeek) set.addAll(m.groceries);

        content.addView(tv("Samengevoegd uit weekmenu + vaste producten",16,true));
        for (String item : set) {
            CheckBox cb = new CheckBox(this);
            cb.setText(item);
            cb.setTextSize(16);
            cb.setPadding(4,8,4,8);
            content.addView(cb);
        }
        Button ahBtn = action(ah.isConnected() ? "Match producten en zet in AH-lijst" : "Koppel eerst Albert Heijn");
        ahBtn.setOnClickListener(v -> {
            if (!ah.isConnected()) showAh();
            else matchAndAdd(new ArrayList<>(set));
        });
        content.addView(ahBtn);
    }

    private void matchAndAdd(List<String> groceryNames) {
        ProgressDialogCompat progress = new ProgressDialogCompat(this, "AH-producten zoeken…");
        progress.show();
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                matchedProducts.clear();
                List<AhClient.AhLine> lines = new ArrayList<>();
                for (String name : groceryNames) {
                    List<AhClient.AhProduct> found = ah.searchProducts(name, 1);
                    if (!found.isEmpty()) {
                        matchedProducts.put(name, found.get(0).id);
                        lines.add(new AhClient.AhLine(found.get(0).id, 1));
                    }
                }
                if (lines.isEmpty()) throw new RuntimeException("Geen AH-producten gematcht.");
                ah.addProductsToShoppingList(lines);
                runOnUiThread(() -> {
                    progress.dismiss();
                    new AlertDialog.Builder(this)
                            .setTitle("Toegevoegd aan AH")
                            .setMessage(lines.size() + " producten zijn rechtstreeks aan je AH-boodschappenlijst toegevoegd. Controleer vervangingen/hoeveelheden in de AH-app.")
                            .setPositiveButton("Open AH", (d,w) -> openAh())
                            .setNegativeButton("Sluiten", null)
                            .show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progress.dismiss();
                    new AlertDialog.Builder(this).setTitle("AH-koppeling")
                            .setMessage(e.getMessage())
                            .setPositiveButton("OK", null).show();
                });
            }
        });
    }

    private void showAh() {
        base("Albert Heijn");
        content.addView(tv(ah.isConnected() ? "Status: gekoppeld" : "Status: niet gekoppeld",18,true));
        content.addView(tv("De koppeling gebruikt de mobiele AH-interface. Dit is geen publiek ondersteunde ontwikkelaars-API en kan door AH veranderen.",14,false));

        if (!ah.isConnected()) {
            Button login = action("Inloggen bij Albert Heijn");
            login.setOnClickListener(v -> showLoginWebView());
            content.addView(login);
        } else {
            Button open = action("Open AH boodschappenlijst");
            open.setOnClickListener(v -> openAh());
            content.addView(open);
            Button logout = action("AH-koppeling verwijderen");
            logout.setOnClickListener(v -> { ah.disconnect(); showAh(); });
            content.addView(logout);
        }
    }

    private void showLoginWebView() {
        WebView web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("appie://login-exit")) {
                    String code = request.getUrl().getQueryParameter("code");
                    if (code != null) exchange(code);
                    return true;
                }
                return false;
            }
        });
        web.loadUrl(ah.getLoginUrl());
        setContentView(web);
    }

    private void handleCallback(Intent intent) {
        Uri data = intent.getData();
        if (data != null && "appie".equals(data.getScheme()) && "login-exit".equals(data.getHost())) {
            String code = data.getQueryParameter("code");
            if (code != null) exchange(code);
        }
    }

    private void exchange(String code) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                ah.exchangeCode(code);
                runOnUiThread(() -> {
                    Toast.makeText(this, "Albert Heijn gekoppeld", Toast.LENGTH_LONG).show();
                    showAh();
                });
            } catch (Exception e) {
                runOnUiThread(() -> new AlertDialog.Builder(this)
                        .setTitle("AH login mislukt")
                        .setMessage(e.getMessage()).setPositiveButton("OK", null).show());
            }
        });
    }

    private void openAh() {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage("com.ahold.mobile.ah");
            if (launch != null) startActivity(launch);
            else startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.ah.nl/mijnlijst")));
        } catch (Exception e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.ah.nl/mijnlijst")));
        }
    }

    private void showSettings() {
        base("Instellingen");
        content.addView(tv("Huishouden",18,true));
        content.addView(tv("• 2 volwassenen altijd thuis\n• dochter in even weken woensdag t/m zondag",15,false));
        content.addView(tv("Weekverdeling",18,true));
        content.addView(tv("• 3 × aardappelen + groente + vlees/vis\n• 1–2 × pasta\n• 1 × rijst\n• 1 × anders",15,false));
        content.addView(tv("Voedingsaccenten",18,true));
        content.addView(tv("• overgang: eiwit, calciumrijke keuzes, groente/vezels, vis, onverzadigde vetten\n• psoriasis: mediterrane basis, veel groente, vis, volkoren, peulvruchten; geen onnodige eliminatiediëten",15,false));
        content.addView(tv("Vaste producten",18,true));
        content.addView(tv("Kinder Bueno • yoghurt • fruit • ongezouten noten",15,false));
        content.addView(tv("Volgende versie: deze waarden worden volledig bewerkbaar inclusief verbodenlijst, maximale kooktijd, budget en vaste ontbijt-/lunchartikelen.",14,false));
    }

    private Button navButton(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text); b.setAllCaps(false); b.setOnClickListener(l);
        return b;
    }
    private Button action(String text) {
        Button b = new Button(this);
        b.setText(text); b.setAllCaps(false); b.setTextSize(16);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(0,14,0,0); b.setLayoutParams(lp);
        return b;
    }
    private TextView tv(String text, int size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextSize(size); v.setTextColor(Color.rgb(30,30,30));
        v.setPadding(0,8,0,8);
        if (bold) v.setTypeface(null, android.graphics.Typeface.BOLD);
        return v;
    }
    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(22,18,22,18);
        c.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(0,12,0,0); c.setLayoutParams(lp);
        return c;
    }

    // Kleine dependency-vrije voortgangsdialoog
    static class ProgressDialogCompat {
        private final AlertDialog dialog;
        ProgressDialogCompat(Activity a, String msg) {
            ProgressBar p = new ProgressBar(a);
            p.setPadding(40,30,40,30);
            LinearLayout box = new LinearLayout(a);
            box.setOrientation(LinearLayout.VERTICAL);
            TextView t = new TextView(a); t.setText(msg); t.setTextSize(16); t.setPadding(30,20,30,10);
            box.addView(t); box.addView(p);
            dialog = new AlertDialog.Builder(a).setView(box).setCancelable(false).create();
        }
        void show(){ dialog.show(); }
        void dismiss(){ if(dialog.isShowing()) dialog.dismiss(); }
    }
}
