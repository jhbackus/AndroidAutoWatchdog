package nl.weekplanner.ah;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class AhClient {
    private static final String TAG = "AhClient";
    private static final String BASE = "https://api.ah.nl";
    private static final String AUTH = BASE + "/mobile-auth/v1/auth";
    private static final String PREFS = "ah_auth";
    private static final String KEY_ALIAS = "ah_weekplanner_token_key";
    private final SharedPreferences prefs;

    public AhClient(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public String getLoginUrl() {
        return "https://login.ah.nl/secure/oauth/authorize"
                + "?client_id=appie"
                + "&redirect_uri=appie%3A%2F%2Flogin-exit"
                + "&response_type=code";
    }

    public boolean isConnected() {
        return prefs.getString("refresh_token_enc", null) != null;
    }

    public void disconnect() {
        prefs.edit().clear().apply();
    }

    public void exchangeCode(String code) throws Exception {
        JSONObject body = new JSONObject();
        body.put("clientId", "appie");
        body.put("code", code);
        JSONObject json = requestJson("POST", AUTH + "/token", null, body);
        saveTokens(json);
    }

    public void refresh() throws Exception {
        String refresh = getSecure("refresh_token");
        if (refresh == null) throw new IllegalStateException("Geen AH refresh token");
        JSONObject body = new JSONObject();
        body.put("clientId", "appie");
        body.put("refreshToken", refresh);
        JSONObject json = requestJson("POST", AUTH + "/token/refresh", null, body);
        saveTokens(json);
    }

    private void saveTokens(JSONObject json) throws Exception {
        String access = json.getString("access_token");
        String refresh = json.getString("refresh_token");
        long expiresIn = json.optLong("expires_in", 7199);
        putSecure("access_token", access);
        putSecure("refresh_token", refresh);
        prefs.edit()
                .putLong("expires_at", System.currentTimeMillis() + (expiresIn - 120) * 1000L)
                .apply();
    }

    private String validAccessToken() throws Exception {
        long expiresAt = prefs.getLong("expires_at", 0);
        if (System.currentTimeMillis() >= expiresAt) refresh();
        String token = getSecure("access_token");
        if (token == null) throw new IllegalStateException("Niet gekoppeld met AH");
        return token;
    }


    private SecretKey getOrCreateKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) {
            return ((KeyStore.SecretKeyEntry) ks.getEntry(KEY_ALIAS, null)).getSecretKey();
        }
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build());
        return kg.generateKey();
    }

    private void putSecure(String name, String value) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
        byte[] iv = c.getIV();
        byte[] enc = c.doFinal(value.getBytes(StandardCharsets.UTF_8));
        prefs.edit()
                .putString(name + "_enc", Base64.encodeToString(enc, Base64.NO_WRAP))
                .putString(name + "_iv", Base64.encodeToString(iv, Base64.NO_WRAP))
                .apply();
    }

    private String getSecure(String name) throws Exception {
        String encS = prefs.getString(name + "_enc", null);
        String ivS = prefs.getString(name + "_iv", null);
        if (encS == null || ivS == null) return null;
        byte[] enc = Base64.decode(encS, Base64.NO_WRAP);
        byte[] iv = Base64.decode(ivS, Base64.NO_WRAP);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, iv));
        return new String(c.doFinal(enc), StandardCharsets.UTF_8);
    }

    public List<AhProduct> searchProducts(String query, int limit) throws Exception {
        String q = URLEncoder.encode(query, StandardCharsets.UTF_8.name());
        JSONObject json = requestJson(
                "GET",
                BASE + "/mobile-services/product/search/v2?query=" + q + "&sortOn=RELEVANCE",
                null,
                null
        );

        List<AhProduct> out = new ArrayList<>();
        JSONArray products = json.optJSONArray("products");
        if (products == null) {
            JSONObject card = json.optJSONObject("cards");
            if (card != null) products = card.optJSONArray("products");
        }
        if (products == null) return out;

        for (int i = 0; i < products.length() && out.size() < limit; i++) {
            JSONObject p = products.optJSONObject(i);
            if (p == null) continue;
            int id = p.optInt("id", p.optInt("productId", 0));
            String title = p.optString("title", p.optString("name", ""));
            if (id > 0 && !title.isEmpty()) out.add(new AhProduct(id, title));
        }
        return out;
    }

    public void addProductsToShoppingList(List<AhLine> lines) throws Exception {
        String token = validAccessToken();
        JSONArray items = new JSONArray();
        for (AhLine line : lines) {
            JSONObject item = new JSONObject();
            item.put("originCode", "PRD");
            item.put("productId", line.productId);
            item.put("quantity", line.quantity);
            item.put("type", "SHOPPABLE");
            items.put(item);
        }
        JSONObject body = new JSONObject();
        body.put("items", items);

        requestJson(
                "PATCH",
                BASE + "/mobile-services/shoppinglist/v2/items?orderBy=userInput&orderByParam=0",
                token,
                body
        );
    }

    private JSONObject requestJson(String method, String endpoint, String bearer, JSONObject body) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(endpoint).openConnection();
        conn.setRequestMethod(method);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(20000);
        conn.setRequestProperty("Accept", "application/json");
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setRequestProperty("User-Agent", "Appie/8.63 Android");
        conn.setRequestProperty("X-Application", "AHWEBSHOP");
        if (bearer != null) conn.setRequestProperty("Authorization", "Bearer " + bearer);

        if (body != null) {
            conn.setDoOutput(true);
            byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(data);
            }
        }

        int code = conn.getResponseCode();
        InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
        String text = readAll(stream);
        if (code < 200 || code >= 300) {
            throw new RuntimeException("AH HTTP " + code + ": " + text);
        }
        if (text == null || text.trim().isEmpty()) return new JSONObject();
        return new JSONObject(text);
    }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        return sb.toString();
    }

    public static class AhProduct {
        public final int id;
        public final String title;
        public AhProduct(int id, String title) { this.id = id; this.title = title; }
    }

    public static class AhLine {
        public final int productId;
        public final int quantity;
        public AhLine(int productId, int quantity) {
            this.productId = productId;
            this.quantity = quantity;
        }
    }
}
