# AH Weekplanner Android v0.1

Eerste werkende bronversie van de persoonlijke weekmenu-app.

## In deze versie
- weekmenu maandag t/m zondag;
- automatisch 3 personen in even weken van woensdag t/m zondag;
- verdeling AVG / pasta / rijst / ander gerecht;
- voedingsaccenten passend bij een gezond mediterraan patroon, overgang en psoriasis;
- vaste boodschappen waaronder Kinder Bueno;
- boodschappenlijst uit recepten;
- directe AH-login via de mobiele OAuth-flow;
- AH access/refresh tokens versleuteld via Android Keystore;
- productzoekopdracht bij AH;
- batch toevoegen aan de AH-boodschappenlijst;
- knop om daarna de AH-app / AH-lijst te openen.

## Belangrijk over de AH-koppeling
De gebruikte mobiele endpoints zijn geen publiek gedocumenteerde partner-API van Albert Heijn.
Albert Heijn kan deze endpoints, headers of OAuth-flow wijzigen. Daarom staat alle AH-logica
in `AhClient.java`, los van de planner.

De app voert de bestelling niet zelfstandig definitief uit; de gebruiker controleert en bevestigt
de bestelling in de officiële AH-omgeving.

## Bouwen
Open de map in een actuele Android Studio-installatie met Android SDK 35 en build `app`.
Deze uitvoeromgeving bevatte geen Android SDK/Gradle-distributie en had geen netwerktoegang
om die componenten te installeren, daarom is hier geen APK meegeleverd.

## Eerstvolgende uitbreidingen
- instellingen echt bewerkbaar maken en lokaal bewaren;
- verbodenlijst / allergieën / dislikes;
- vaste ontbijt- en lunchproducten;
- receptvervanging en favorieten;
- portie- en hoeveelheidberekening;
- voorraad;
- AH productmatch laten bevestigen bij twijfel;
- Bonus / eerder gekocht meenemen;
- bestelritme maandag.
