package nl.weekplanner.ah;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.WeekFields;
import java.util.*;

public class PlannerEngine {
    public static class Meal {
        public final String day;
        public final int persons;
        public final String title;
        public final String category;
        public final List<String> groceries;
        Meal(String day, int persons, String title, String category, String... groceries) {
            this.day = day; this.persons = persons; this.title = title; this.category = category;
            this.groceries = Arrays.asList(groceries);
        }
    }

    private final List<MealTemplate> potatoes = Arrays.asList(
            new MealTemplate("Zalm, krieltjes en broccoli", "AVG/vis", "zalm", "krieltjes", "broccoli", "citroen", "olijfolie"),
            new MealTemplate("Kipfilet, aardappelen en sperziebonen", "AVG/vlees", "kipfilet", "aardappelen", "sperziebonen"),
            new MealTemplate("Mager gehakt, bloemkool en aardappelpuree", "AVG/vlees", "mager gehakt", "bloemkool", "aardappelen", "halfvolle melk"),
            new MealTemplate("Kabeljauw, aardappeltjes en spinazie", "AVG/vis", "kabeljauw", "aardappeltjes", "spinazie")
    );
    private final List<MealTemplate> pasta = Arrays.asList(
            new MealTemplate("Volkoren pasta met kip, spinazie en tomaat", "Pasta", "volkoren pasta", "kipfilet", "spinazie", "tomaten", "knoflook"),
            new MealTemplate("Volkoren pasta bolognese met extra groente", "Pasta", "volkoren pasta", "mager rundergehakt", "tomatenblokjes", "courgette", "wortel", "ui")
    );
    private final List<MealTemplate> rice = Arrays.asList(
            new MealTemplate("Zilvervliesrijst met kip, paprika en cashewnoten", "Rijst", "zilvervliesrijst", "kipfilet", "paprika", "broccoli", "cashewnoten"),
            new MealTemplate("Zilvervliesrijst met zalm, edamame en wokgroente", "Rijst", "zilvervliesrijst", "zalm", "edamame", "wokgroente")
    );
    private final List<MealTemplate> other = Arrays.asList(
            new MealTemplate("Volkoren wraps met kip, avocado en rauwkost", "Anders", "volkoren wraps", "kipfilet", "avocado", "sla", "tomaat", "komkommer"),
            new MealTemplate("Linzen-curry met spinazie en yoghurt", "Anders", "linzen", "spinazie", "tomatenblokjes", "Griekse yoghurt", "currypasta")
    );

    public List<Meal> makeWeek(LocalDate monday) {
        List<MealTemplate> picks = new ArrayList<>();
        picks.add(potatoes.get(0));
        picks.add(pasta.get(0));
        picks.add(potatoes.get(1));
        picks.add(rice.get(0));
        picks.add(potatoes.get(2));
        picks.add(pasta.get(1));
        picks.add(other.get(0));

        List<Meal> out = new ArrayList<>();
        for (int i = 0; i < 7; i++) {
            LocalDate date = monday.plusDays(i);
            int persons = personsFor(date);
            MealTemplate t = picks.get(i);
            out.add(new Meal(dayName(date), persons, t.title, t.category, t.groceries.toArray(new String[0])));
        }
        return out;
    }

    public int personsFor(LocalDate date) {
        int week = date.get(WeekFields.ISO.weekOfWeekBasedYear());
        DayOfWeek d = date.getDayOfWeek();
        boolean daughterHome = (week % 2 == 0) &&
                (d == DayOfWeek.WEDNESDAY || d == DayOfWeek.THURSDAY ||
                 d == DayOfWeek.FRIDAY || d == DayOfWeek.SATURDAY || d == DayOfWeek.SUNDAY);
        return daughterHome ? 3 : 2;
    }

    private String dayName(LocalDate d) {
        String[] names = {"Maandag","Dinsdag","Woensdag","Donderdag","Vrijdag","Zaterdag","Zondag"};
        return names[d.getDayOfWeek().getValue()-1];
    }

    private static class MealTemplate {
        final String title, category;
        final List<String> groceries;
        MealTemplate(String title, String category, String... groceries) {
            this.title = title; this.category = category; this.groceries = Arrays.asList(groceries);
        }
    }
}
